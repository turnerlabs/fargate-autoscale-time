var scale = require('./scale');

scale.handler(null,null,function() {
  console.log('done');
});
